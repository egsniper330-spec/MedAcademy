/**
 * VdoCipherPlayerNativeAdapter.native.tsx
 *
 * Native SDK adapter for Android and iOS — ONE VdoPlayerView for the whole
 * watch session.
 *
 * Metro resolves this file in preference to VdoCipherPlayerNativeAdapter.tsx
 * on Android and iOS, while the bare .tsx stub is used on Web.
 *
 * ── Public API ──────────────────────────────────────────────────────────────
 * Identical to the original VdoCipherPlayer props — lesson screens require
 * no changes (onFullscreen is now actually forwarded).
 *
 * ── FULLSCREEN + ROTATION (root-cause architecture) ─────────────────────────
 * Fullscreen is IN-PLACE expansion of the SAME VdoPlayerView inside the SAME
 * activity/window — NOT a Modal. The previous Modal created a SECOND native
 * window (Dialog) hosting a SECOND VdoPlayerView: on rotation that window's
 * surface was destroyed/recreated around a still-running decoder → black
 * video with live audio (VdoCipher error 6120 territory; the docs
 * specifically warn that >1 VdoPlayer instance makes renderer errors far
 * more common). In-place expansion has no second window and no second
 * player: MainActivity's manifest configChanges
 * (orientation|screenSize|screenLayout|…) keeps the activity alive, RN
 * re-measures the container, and the SDK resizes its own surface within it.
 * ONE player instance → no remount, no seek/state restoration between
 * inline ↔ fullscreen (position is continuous by construction), no surface
 * teardown, no duplicate DRM session, and audio/video can never
 * desynchronize across rotation.
 *
 * Orientation: ANDROID locks LANDSCAPE while fullscreen, PORTRAIT_UP
 * otherwise (one useEffect keyed on isFullscreen). iOS is NEVER locked —
 * the device orientation is left exactly as the user holds it and the
 * system Rotation Lock is always respected; only the layout adapts.
 *
 * ── Fullscreen entry per platform ───────────────────────────────────────────
 * • Android: the SDK's native control bar provides the fullscreen button;
 *   tapping it fires onEnterFullscreen → we expand the same instance.
 *   The SDK's exit control fires onExitFullscreen → we collapse.
 * • iOS (fixed): the SDK control bar DOES render a fullscreen button since
 *   bridge 2.9.4 (didTapEnterFullScreen → onEnterFullscreen). It is the ONE
 *   enter control and is mapped into the app's single fullscreen state —
 *   the app-level duplicate button was REMOVED (two competing fullscreen
 *   systems produced the duplicated buttons and the split-screen UI).
 *   Fullscreen NEVER changes the device orientation on iOS: Portrait stays
 *   Portrait, Landscape stays Landscape, Rotation Lock is never bypassed.
 * Exit: the SDK's exit control and the safe-area-aware back arrow both call
 *   the same exitFullscreen(); Android hardware back collapses it.
 *
 * ── Security ────────────────────────────────────────────────────────────────
 * Fullscreen entry re-validates the authoritative SecurityContext verdict
 * (shouldAllowFullscreen — fail-closed). While fullscreen, a NEW violation
 * re-closes it via the live-gate mirror below. Screen capture protection
 * (app-shell FLAG_SECURE lock) is untouched; the watermark overlay lives
 * INSIDE the expanding container so it is visible in both modes.
 *
 * ── Event mapping ───────────────────────────────────────────────────────────
 * onLoaded → onReady(); onProgress(ms) → onProgress(sec, dur); onMediaEnded →
 * onEnd(); onLoadError → onError(message).
 */

import { useRef, useState, useCallback, useEffect, useMemo } from 'react';
import { BackHandler, Platform, Pressable, StatusBar, Text, View, ActivityIndicator, useColorScheme } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';
import { ArrowLeft } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { VdoPlayerView } from 'vdocipher-rn-bridge';
import { useFullscreenWindowDims } from '@/lib/useFullscreenWindowDims';
import { useSecurityPlaybackStop } from '@/lib/useSecurityPlaybackStop';
import { playerSessionMount, playerSessionUnmount } from '@/lib/vdoPlayerSession';
import { getVideoPlaybackToken } from '@/lib/api';
import { neuColors, mutedTextStyle } from '@/lib/neu';
import type { VdoCipherPlayerProps } from '@/components/VdoCipherPlayer';
import { NativeWatermarkOverlay } from '@/components/NativeWatermarkOverlay';
import { t } from '@/lib/i18n';
import { resolveWatermarkIdentity } from '@/lib/watermarkIdentity';
import { resolveWatermarkLayers, type WatermarkPlatform } from '@/lib/watermarkLayers';
import {
  enterFullscreenSystemUi,
  exitFullscreenSystemUi,
} from '@/lib/fullscreenSystemUi';

// ─── Container styles ─────────────────────────────────────────────────────────
//
// INLINE (normal): 16:9 block in the page flow.
//   • position:'relative' — containing block for the NativeWatermarkOverlay
//     (position:'absolute'), keeping the watermark clipped to the player
//     frame (with overflow:'hidden') in normal mode.
//   • overflow:'hidden' — clips the watermark pill to the card's rounded
//     bounds; irrelevant in fullscreen (the container IS the screen then,
//     and its own inset clamps apply).
//
// FULLSCREEN: absolute-fill of the SCREEN ROOT (the lesson screen hosts this
// component as a direct child of its root View) — same window, same player
// instance, same decoder surface. Rotation only re-measures the container.

const INLINE_STYLE = {
  width:      '100%' as const,
  aspectRatio: 16 / 9,
  backgroundColor: '#000',
  position:   'relative' as const,
  overflow:   'hidden'   as const,
};

// Log gate: dimensions/state-only watermark diagnostics (VDO_WM_*).
// DEV builds only — the physical fullscreen/watermark investigation is closed,
// so production builds do no diagnostic logging here (no overhead, no
// PLYR_FS_*/VDO_WM_* noise). Set to `true` temporarily when a release build
// needs an on-device evidence run, and flip it back before shipping.
const RELEASE_DIAG = false;

const FULLSCREEN_STYLE_BASE = {
  position: 'absolute' as const,
  top: 0,
  left: 0,
  zIndex: 100,
  backgroundColor: '#000' as const,
};

// Fullscreen style factory: CONCRETE window pixels instead of edge-anchored
// fill. An absolute-fill chain collapses to height 0 if any ancestor lays out
// at 0 during the enter+rotate churn — that collapse hid the RN watermark
// overlay (button path) while the native SurfaceView kept drawing. Explicit
// dimensions are ancestor-independent.
function fullscreenStyle(win: { width: number; height: number }) {
  return {
    ...FULLSCREEN_STYLE_BASE,
    width: win.width,
    height: win.height,
  };
}

// ─── Component ────────────────────────────────────────────────────────────────


/** DEV-ONLY session scope: registers the mounted native player ONLY while the
 *  real VdoPlayerView tree is rendered (early-exit loading/error paths never
 *  count). Release builds: playerSession* are no-ops. */
function VdoSessionScope({ tag, children }: { tag: string; children: React.ReactNode }) {
  useEffect(() => {
    playerSessionMount(tag);
    return () => playerSessionUnmount(tag);
  }, [tag]);
  return <>{children}</>;
}

export function VdoCipherPlayerNativeAdapter({
  videoId,
  lessonId,
  watermarkId,
  watermarkName,
  onReady,
  onProgress,
  onEnd,
  onError,
  onFullscreen,
  shouldAllowFullscreen,
  fullscreenVerdictNow,
}: VdoCipherPlayerProps) {
  const isDark = useColorScheme() === 'dark';
  const c = isDark ? neuColors.dark : neuColors.light;
  const insets = useSafeAreaInsets();

  // ── SECURITY CONTAINMENT: pause the native player the instant the central
  // security lock engages (soft provisional containment from the native VPN
  // callback included), BEFORE any React re-render could unmount it. React
  // unmounting is the screen's job (hard lock); this is the synchronous stop
  // that also covers an in-place FULLSCREEN player. */}
  const playerRef = useSecurityPlaybackStop();

  // WATERMARK IDENTITY — the ONE authoritative resolver (shared with offline).
  // Public MED-#### id only; a UUID in the id slot is dirty data and renders
  // nothing (never the internal DB user id). Stable across re-renders — the
  // identity cannot flip mid-session.
  const identity = useMemo(
    () => resolveWatermarkIdentity(
      watermarkId ? { public_user_id: watermarkId, watermark_id: watermarkId, full_name: watermarkName } : null
    ),
    [watermarkId, watermarkName]
  );

  // ── DEV-ONLY player-session observability (6120 evidence gathering) ──────
  // Real native mount/unmount counts — release builds are no-ops. The online
  // player unmounts on screen blur (lesson screen), so this must read exactly
  // one active session at any time. A concurrent mount (e.g. an offline
  // player) prints an explicit warning naming every live session.
  const sessionTag = `vdo-online-${videoId.slice(0, 8)}`;


  const [otp, setOtp]               = useState<string | null>(null);
  const [playbackInfo, setPlaybackInfo] = useState<string | null>(null);
  // TRUE when the OTP carries VdoCipher's burned-in MOVING watermark. In that
  // case this component must NOT render NativeWatermarkOverlay — the two
  // together were the reported duplicate watermark.
  const [annotateApplied, setAnnotateApplied] = useState(false);
  // ── WHICH WATERMARK LAYER THIS SESSION SHOWS ──────────────────────────
  // `annotateApplied` alone cannot decide: the OTP is byte-identical for
  // every platform, but only the VdoCipher WEB renderer (and the iOS native
  // SDK) draw the provider's burned-in `rtext` annotation. On Android the
  // native SDK path does not — and because this component used to suppress
  // its own overlay whenever `annotateApplied` was true, Android was left
  // with NEITHER watermark (the reported "does not appear at all").
  // resolveWatermarkLayers owns that single decision for every player.
  const wmPlatform: WatermarkPlatform = Platform.OS === 'ios' ? 'ios' : 'android';
  const watermarkLayers = useMemo(
    () => resolveWatermarkLayers({
      platform: wmPlatform,
      playerKind: 'native',
      annotateApplied,
      hasIdentity: !!identity,
    }),
    [wmPlatform, annotateApplied, identity]
  );
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);

  // Duration captured from onLoaded → forwarded on every onProgress tick.
  const durationSecRef = useRef(0);

  // ── Fullscreen state — the SINGLE owner of fullscreen + orientation ───────
  // The same VdoPlayerView instance stays mounted through every transition;
  // only the container style toggles between INLINE_STYLE and FULLSCREEN_STYLE.
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Explicit window pixels for the fullscreen container (ancestor-collapse fix
  // — same root cause as the Plyr fullscreen black frame).
  const win = useFullscreenWindowDims(isFullscreen);

  // ── ONE fullscreen entry: the SDK's own control-bar button ────────────────
  // The VdoCipher SDK control bar supplies the ONLY user-facing fullscreen
  // entry on BOTH platforms (Android always; iOS since bridge 2.9.4 via
  // didTapEnterFullScreen → onEnterFullscreen). Its enter/exit events are mapped
  // into the single state below, which drives the canonical in-place expansion
  // (security gate + explicit window-pixel expansion of the SAME VdoPlayerView)
  // with the watermark overlay inside it. The RN bridge patch makes the SDK's
  // fullscreen listener report "handled", so the SDK never promotes its own
  // surface above the React Native tree — there is exactly ONE fullscreen
  // system and no app-owned duplicate button.

  // Forward enter/exit to the host screen (contract: host may hide non-video
  // chrome; with the pinned-player layout this is cosmetic redundancy).
  useEffect(() => {
    onFullscreen?.(isFullscreen);
  }, [isFullscreen, onFullscreen]);

  // VDO_WM_MOUNT — release-safe lifecycle evidence: does the app watermark
  // overlay stay MOUNTED (and with which public id) across the fullscreen
  // transition? An unmount here would be the smoking gun for a disappearing
  // watermark; a mount with a stale frame points at z-order/clipping instead.
  useEffect(() => {
    console.log(`[VDO_WM_MOUNT] mounted=${identity ? 'true' : 'false'} wmId=${identity ? identity.id : 'none'} fullscreen=${isFullscreen ? 'true' : 'false'}`);
  }, [identity, isFullscreen]);

  // ── Orientation — Android-only locks; iOS is NEVER locked ─────────────────
  // iOS keeps the orientation the user holds and the system Rotation Lock is
  // never overridden (see the header comment). Android locks landscape while
  // fullscreen and restores portrait on exit.
  useEffect(() => {
    if (Platform.OS !== 'android') return;
    if (!isFullscreen) return;
    void ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE).catch(() => {});
    return () => {
      void ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP).catch(() => {});
    };
  }, [isFullscreen]);

  // Tracks mount state so an async security evaluation that resolves after
  // navigation away cannot enter fullscreen (and strand the orientation).
  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  // ── (orientation handled above) ─────────────────────────────────────────────
  // iOS (the bug fixed here): NO orientation API is touched at all. Entering
  // fullscreen keeps whatever orientation the user is currently in (Portrait
  // stays Portrait, Landscape stays Landscape), the system Rotation Lock is
  // never overridden, and the app's supported orientations (app.json) govern.
  // The absolute-fill container simply re-measures to the window it gets.
  // Android: landscape while fullscreen, portrait otherwise (unchanged — the
  // in-place expansion + manifest configChanges keep the ONE player instance
  // alive through rotation; this is the 6120-safe path).
  useEffect(() => {
    if (!isFullscreen) return;
    void enterFullscreenSystemUi();
    return () => {
      void exitFullscreenSystemUi();
    };
  }, [isFullscreen]);

  // ── SECURITY: live gate mirror while fullscreen ────────────────────────────
  // A NEW security violation (e.g. VPN enabled mid-playback) must collapse
  // fullscreen. We re-run the host-supplied authoritative gate on an interval
  // — the same fail-closed callback used at entry — and exit when it refuses.
  const shouldAllowRef = useRef(shouldAllowFullscreen);
  shouldAllowRef.current = shouldAllowFullscreen;
  useEffect(() => {
    if (!isFullscreen) return;
    let cancelled = false;
    const recheck = async () => {
      const gate = shouldAllowRef.current;
      if (!gate) return; // gateless surface (never the lesson screen)
      try {
        const ok = await gate();
        if (!cancelled && ok === false) setIsFullscreen(false);
      } catch {
        if (!cancelled) setIsFullscreen(false); // evaluation error → fail-closed
      }
    };
    const iv = setInterval(recheck, 5000);
    void recheck();
    return () => { cancelled = true; clearInterval(iv); };
  }, [isFullscreen]);

  // ── Fetch OTP on mount (identical flow to WebView player) ────────────────
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    setOtp(null);
    setPlaybackInfo(null);
    setAnnotateApplied(false);
    setIsFullscreen(false);
    durationSecRef.current = 0;

    (async () => {
      try {
        const result = await getVideoPlaybackToken(videoId, lessonId);
        if (!cancelled) {
          setOtp(result.otp);
          setPlaybackInfo(result.playbackInfo);
          setAnnotateApplied(result.annotateApplied === true);
          setLoading(false);
        }
      } catch (err: any) {
        if (!cancelled) {
          const msg = err?.message ?? 'Unable to load video. Please try again.';
          setError(msg);
          setLoading(false);
          onError?.(msg);
        }
      }
    })();

    return () => { cancelled = true; };
  }, [videoId, lessonId]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Event handlers ────────────────────────────────────────────────────────

  // onLoaded fires when the media is ready to play.
  // mediaInfo.duration is in milliseconds.
  const handleLoaded = useCallback((event: any) => {
    const durationMs = event?.mediaInfo?.duration ?? 0;
    durationSecRef.current = durationMs / 1000;
    onReady?.();
  }, [onReady]);

  // onProgress fires roughly every second.
  // event.currentTime is in milliseconds.
  const handleProgress = useCallback((event: any) => {
    const currentTimeSec = (event?.currentTime ?? 0) / 1000;
    onProgress?.(currentTimeSec, durationSecRef.current);
  }, [onProgress]);

  // onMediaEnded fires when playback reaches the end.
  const handleMediaEnded = useCallback((_event: any) => {
    onEnd?.();
  }, [onEnd]);

  // onLoadError fires when the SDK fails to load the media.
  const handleLoadError = useCallback((event: any) => {
    const msg =
      event?.errorDescription?.errorMsg ??
      `Playback error (code: ${event?.errorDescription?.errorCode ?? 'unknown'})`;
    setError(msg);
    onError?.(msg);
  }, [onError]);

  // ── Fullscreen enter/exit (SAME player instance both ways) ────────────────
  const enterFullscreen = useCallback(async () => {
    // Rotation is requested by the isFullscreen effect above, once fullscreen
    // is committed. (The early rotation that overlapped the security gate was
    // removed: it could leave the device rotated if the gate refused.)
    // ── INSTANT ENTRY ON THE LIVE VERDICT (fullscreen latency) ───────────────
    // The host's PUBLISHED verdict decides entry synchronously, so fullscreen
    // commits in the same frame as the tap. The authoritative gate is NOT
    // skipped: the live gate mirror above re-runs it immediately when
    // isFullscreen flips (and every 5s while fullscreen) and collapses
    // fullscreen the moment it refuses — the same fail-closed path that already
    // handles a violation appearing mid-playback.
    if (fullscreenVerdictNow) {
      let allowedNow = false;
      try {
        allowedNow = fullscreenVerdictNow() === true;
      } catch {
        allowedNow = false; // evaluation error → no fullscreen
      }
      if (!allowedNow) return;
      setIsFullscreen(true);
      return;
    }

    // ── FALLBACK (no sync verdict wired): previous blocking semantics ────────
    // SECURITY GATE — fail-closed: blocked state, in-flight evaluation, or a
    // thrown error all refuse fullscreen.
    if (shouldAllowFullscreen) {
      try {
        if (!(await shouldAllowFullscreen())) return;
      } catch {
        return;
      }
      // Unmounted or lesson changed while the gate was pending: never enter.
      if (!mountedRef.current) return;
    }
    setIsFullscreen(true);
  }, [shouldAllowFullscreen, fullscreenVerdictNow]);

  // Local collapse only. Used by the SDK's own exit event, which has already
  // left the SDK's fullscreen, so it must not call back into the SDK.
  const collapseFullscreen = useCallback(() => {
    setIsFullscreen(false);
  }, []);

  // App-initiated exit (back arrow, Android back): asks the SDK to leave its
  // fullscreen too, so the SDK's state and the app's state stay in sync.
  const exitFullscreen = useCallback(() => {
    try {
      playerRef.current?.exitFullscreenV2?.();
    } catch {
      /* player not ready — local state still collapses */
    }
    setIsFullscreen(false);
  }, [playerRef]);

  // SDK fullscreen events — THE single fullscreen control on both platforms.
  // The SDK control-bar button (Android always; iOS since bridge 2.9.4) fires
  // these; both are mapped into the ONE isFullscreen state. Entry re-runs the
  // security gate; there is no second, app-level enter control.
  const handleSdkEnterFullscreen = useCallback(() => {
    void enterFullscreen();
  }, [enterFullscreen]);
  const handleSdkExitFullscreen = useCallback(() => {
    collapseFullscreen();
  }, [collapseFullscreen]);

  // Android hardware back collapses fullscreen (in-place → BackHandler, not
  // Modal onRequestClose).
  useEffect(() => {
    if (!isFullscreen || Platform.OS !== 'android') return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      exitFullscreen();
      return true;
    });
    return () => sub.remove();
  }, [isFullscreen, exitFullscreen]);

  // ── embedInfo IDENTITY (the 6120 root cause) ─────────────────────────────
  // The bridge's native `setEmbedInfo` does NOT diff: every time React hands it
  // a new object it builds VdoInitParams and calls `vdoPlayer.load(params)`
  // again. An inline literal (`embedInfo={{ otp, playbackInfo, ... }}`) is a new
  // object on EVERY render, so each state change on this screen (loading flag,
  // annotate flag, fullscreen, error, progress-driven re-render) re-INITIALISED
  // the player underneath the user. VdoCipher's own error table lists multiple
  // concurrent player initialisations as the most common cause of error 6120
  // ("Renderer Error") — the DRM failure this screen reported.
  //
  // Memoising on the only two values that matter gives the native view ONE
  // stable payload per session: `load()` runs once on mount and never again
  // until the OTP itself changes. The view is never remounted either, so the
  // decoder/DRM session survives fullscreen, rotation and re-renders.
  const embedInfo = useMemo(
    () => ({ otp: otp ?? '', playbackInfo: playbackInfo ?? '', enableAutoResume: true }),
    [otp, playbackInfo],
  );

  // ── Loading ───────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <View style={[INLINE_STYLE, { alignItems: 'center', justifyContent: 'center', gap: 10 }]}>
        <ActivityIndicator color={c.primary} size="large" />
        <Text style={{ fontSize: 13, ...mutedTextStyle(c, 0.5) }}>{t('player.loading')}</Text>
      </View>
    );
  }

  // ── Error ─────────────────────────────────────────────────────────────────
  if (error || !otp || !playbackInfo) {
    return (
      <View style={[INLINE_STYLE, {
        backgroundColor: '#0A0A0A',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 24,
        gap: 8,
      }]}>
        <Text style={{ fontSize: 14, fontWeight: '700', color: '#fff', textAlign: 'center' }}>
          {t('player.unavailable')}
        </Text>
        <Text style={{ fontSize: 12, color: '#ffffff88', textAlign: 'center', lineHeight: 18 }}>
          {error ?? 'Could not load the player. Please check your connection.'}
        </Text>
      </View>
    );
  }

  // ── Native SDK player — ONE instance for the whole session ────────────────
  //
  // embedInfo.enableAutoResume=true activates VdoCipher's server-side resume
  // feature so the SDK automatically seeks to the last saved position on load.
  // ── showNativeControls MUST STAY ENABLED — do not pass false ─────────────
  //
  // The VdoCipher SDK control bar is the ONLY source of user playback control
  // in this player: play/pause, the timeline (position + duration), drag-to-seek
  // and the ±10s rewind/forward buttons. There is no app-level replacement —
  // this component renders only the watermark overlay — fullscreen comes from
  // the same SDK bar.
  //
  // Setting it to false does NOT "declutter" the view. The bridge then renders
  // an entirely different native view (VdoPlayerSupportView → RCTVdoPlayerView)
  // that has NO control bar at all: tapping the video reveals nothing, the
  // timeline is gone, and playback can neither be paused nor seeked — it just
  // runs until the user leaves the screen. It ALSO silently disables the
  // MEDACADEMY single-fullscreen-entry patch, because that patch lives in
  // ReactVdoPlayerUIView, the class only used when the bar is enabled.
  //
  // Enabling the bar also supplies the ONE fullscreen entry. The bridge patch
  // makes the SDK's own fullscreen listener report "handled", so that button
  // drives this component's in-place fullscreen instead of the surface-promoting
  // default, leaving play/seek/quality/speed/captions untouched
  // (see patches/vdocipher-rn-bridge+2.0.1.patch).
  //
  // autoPlay=true mirrors the original WebView behaviour.

  return (
    <VdoSessionScope tag={sessionTag}>
    <View
      style={isFullscreen ? fullscreenStyle(win) : INLINE_STYLE}
      onLayout={(e) => {
        // VDO_WM_FULLSCREEN_CONTAINER: the player/watermark container's ACTUAL
        // laid-out frame. Fullscreen must equal the current window dims — a
        // stale portrait frame is the iOS rotation failure signature; a 0×0
        // or stale size explains a buried/absent watermark. Dimensions only.
        const { width, height } = e.nativeEvent.layout;
        if (RELEASE_DIAG || __DEV__) {
          console.log(`[VDO_WM_FULLSCREEN_CONTAINER] w=${width.toFixed(0)} h=${height.toFixed(0)} fullscreen=${isFullscreen ? 'true' : 'false'}`);
        }
      }}
    >
      {isFullscreen && <StatusBar hidden />}
      <VdoPlayerView
        ref={playerRef}
        embedInfo={embedInfo}
        showNativeControls
        autoPlay
        style={{ flex: 1 }}
        onLoaded={handleLoaded}
        onProgress={handleProgress}
        onMediaEnded={handleMediaEnded}
        onLoadError={handleLoadError}
        onEnterFullscreen={handleSdkEnterFullscreen}
        onExitFullscreen={handleSdkExitFullscreen}
      />
      {/* Application watermark — the APP layer, with continuous billiard
          motion (watermarkMotion.ts) that reflects off the four bounds of the
          real video viewport.

          Whether it renders is decided by resolveWatermarkLayers, NOT by the
          local `annotateApplied` flag: exactly one watermark is ever shown
          (the provider's stream-burned mark when it actually draws — iOS
          native and the web player — this overlay otherwise). On Android the
          native SDK does not draw the provider annotation, so this overlay is
          the ONLY watermark the student gets; suppressing it here (the old
          rule) is what produced "no watermark on Android at all".

          Lives INSIDE the expanding container → correct in normal AND
          fullscreen, and re-projected on every resize/rotation. */}
      {/* NO app-level fullscreen button. The SDK control bar's OWN fullscreen
          button (Android always; iOS since bridge 2.9.4) is the single entry,
          and it maps into the in-place fullscreen state above — one fullscreen
          system, watermark overlay inside it. */}

      {identity && watermarkLayers.appOverlay && (
        <NativeWatermarkOverlay
          watermarkId={identity.id}
          watermarkName={identity.name ?? undefined}
          debugProve={__DEV__}
          onContainerLayout={(e) => {
            // VDO_WM_OVERLAY_FRAME: the watermark overlay's ACTUAL laid-out
            // frame inside the SAME container as VdoPlayerView. In fullscreen
            // this MUST equal the window (e.g. 1200x1928 portrait / 1928x1200
            // landscape) — a stale portrait frame here means the overlay
            // hierarchy did not follow the fullscreen expansion; 0×0 means
            // the overlay's parent collapsed. Dimensions/state only.
            const { width, height } = e.nativeEvent.layout;
            if (RELEASE_DIAG || __DEV__) {
              console.log(`[VDO_WM_OVERLAY_FRAME] w=${width.toFixed(0)} h=${height.toFixed(0)} fullscreen=${isFullscreen ? 'true' : 'false'}`);
            }
          }}
        />
      )}

      {/* FULLSCREEN ENTRY — the SDK control bar's OWN fullscreen button, on BOTH
          platforms:
            • Android: the native control bar's enter/exit fullscreen buttons are
              the user-facing controls; they fire onEnterFullscreen /
              onExitFullscreen → the single app fullscreen state above.
            • iOS: the SDK control bar renders its own fullscreen button since
              bridge 2.9.4 (didTapEnterFullScreen → onEnterFullscreen) → same state.
          The RN bridge patch (patches/vdocipher-rn-bridge+2.0.1.patch) keeps the
          SDK's fullscreen listener reporting "handled", so the SDK never
          promotes its own surface above the React Native tree: playback stays
          inside this container, which is where the watermark overlay lives.
          Play/pause, timeline, drag-seek, ±10s, quality, speed and captions are
          untouched.
          Exit paths: the SDK's own exit control, this component's back arrow,
          and the Android hardware back button — all collapse the same
          exitFullscreen() state. */}

      {/* EXIT-fullscreen control (both platforms) — the single app-level exit
          affordance for the app's fullscreen path, safe-area aware so it never
          sits under the status area. Collapses the SAME instance back into the
          inline layout; playback continues uninterrupted (same player, same
          position, no recreation). The SDK's own exit control fires
          onExitFullscreen → exitFullscreen() above as well. */}
      {isFullscreen && (
        <Pressable
          onPress={exitFullscreen}
          style={{
            position: 'absolute',
            top: Math.max(12, insets.top + 8),
            left: Math.max(12, insets.left + 8),
            width: 44,
            height: 44,
            borderRadius: 22,
            backgroundColor: '#00000080',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 999,
          }}
          accessibilityLabel={t('player.exitFullscreen')}
          accessibilityRole="button"
          hitSlop={{ top: 8, right: 8, bottom: 8, left: 8 }}
        >
          <ArrowLeft size={22} color="#fff" />
        </Pressable>
      )}
    </View>
    </VdoSessionScope>
  );
}
