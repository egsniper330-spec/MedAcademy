<?php

declare(strict_types=1);

namespace MedAcademy\Controllers;

use MedAcademy\Database\Database;
use MedAcademy\Http\Request;
use MedAcademy\Http\Response;
use MedAcademy\Http\ApiException;

/**
 * Generic data controller — handles Supabase-compatible `.from('table')` queries.
 *
 * SECURITY:
 * - Table allowlist enforced
 * - Column names validated against identifier regex (prevents SQL injection)
 * - Sensitive tables require admin role
 * - Mass assignment prevented for sensitive columns
 * - All values use parameterized queries
 */
class DataController
{
    /** Tables readable by any authenticated user */
    private const PUBLIC_TABLES = [
        'academic_levels', 'app_branding', 'app_pages', 'categories',
        'content_protection_policies', 'course_templates', 'faculties',
        'feature_flags', 'support_settings', 'system_config', 'universities',
        'video_providers', 'video_provider_config',
    ];

    /** Tables readable only by admin/super_admin */
    private const ADMIN_TABLES = [
        'activation_codes', 'activation_codes_summary', 'activation_ledger_view',
        'analytics_events', 'audit_logs', 'code_batches',
        'content_protection_violations', 'course_lifecycle_logs', 'courses',
        'crash_logs', 'credit_daily_stats', 'credit_ledger_view',
        'credit_transactions', 'credits', 'credits_summary', 'device_stats',
        'devices', 'doctor_credit_summary', 'doctor_earnings_events',
        'doctor_earnings_transactions', 'doctor_payout_requests',
        'doctor_pricing_history', 'enrollments', 'fraud_flags',
        'lesson_materials', 'lesson_progress', 'lessons',
        'maintenance_whitelist', 'notifications', 'platform_earnings_resets',
        'profiles', 'provider_audit_log', 'revenue_analytics', 'sections',
        'security_events', 'security_policies', 'security_vpn_whitelist',
        'trash_config', 'upload_audit_logs', 'upload_sessions',
        'video_assets', 'video_daily_health_reports', 'video_health_alerts',
        'video_uploads',
    ];

    /** All allowed tables (union of public + admin) */
    private const ALL_TABLES = [...self::PUBLIC_TABLES, ...self::ADMIN_TABLES];

    /** Tables that are read-only via this controller (INSERT/UPDATE/DELETE blocked) */
    private const READ_ONLY_TABLES = [
        'activation_codes_summary', 'activation_ledger_view',
        'credit_daily_stats', 'credit_ledger_view', 'credits_summary',
        'device_stats', 'doctor_credit_summary', 'revenue_analytics',
        'course_lifecycle_logs', 'audit_logs', 'upload_audit_logs',
        'provider_audit_log', 'analytics_events', 'crash_logs',
        'doctor_earnings_events', 'doctor_earnings_transactions',
        'doctor_payout_requests', 'doctor_pricing_history',
        'video_daily_health_reports', 'video_health_alerts',
    ];

    /** Columns that must never be set via the generic API (prevents mass assignment) */
    private const PROTECTED_COLUMNS = [
        'role', 'status', 'is_admin', 'is_super_admin', 'unlimited_devices',
        'access_token', 'password', 'encrypted_password', 'reset_token',
        'service_role', 'jwt_secret',
    ];

    /** Valid MySQL identifier pattern — prevents SQL injection in column/table names */
    private const IDENTIFIER_REGEX = '/^[a-zA-Z_][a-zA-Z0-9_]*$/';

    /**
     * SELECT from table — GET /api/{table}?select=*&col=val&order=col.asc&limit=10
     */
    public function select(Request $request): void
    {
        $table = $this->extractTableFromPath($request);
        $this->assertAllowed($table, 'read');
        $this->assertAdminForTable($table, $request);

        $db = Database::instance();
        $params = $request->query();

        // Build SELECT columns — validate each column name
        $selectRaw = $params['select'] ?? '*';
        $selectCols = $this->validateSelectColumns($selectRaw);
        $select = $selectCols === ['*'] ? '*' : implode(', ', array_map(fn($c) => "`{$c}`", $selectCols));

        // Build WHERE clauses from query params
        $where = [];
        $bindings = [];
        foreach ($params as $key => $value) {
            if (in_array($key, ['select', 'order', 'limit', 'offset', 'range'], true)) continue;

            // Handle PostgREST-style operators: col=eq.val, col=gt.val, etc.
            if (preg_match('/^(.+?)\.(eq|neq|gt|gte|lt|lte|like|ilike|in|is|contains|contained_by|overlaps)\.(.+)$/', $value, $m)) {
                $col = $m[1];
                $op = $m[2];
                $val = $m[3];
            } else {
                $col = $key;
                $op = 'eq';
                $val = $value;
            }

            // Validate column name
            $col = $this->sanitizeIdentifier($col);
            $this->assertValidIdentifier($col, 'column');

            switch ($op) {
                case 'eq':    $where[] = "`{$col}` = ?"; $bindings[] = $val; break;
                case 'neq':   $where[] = "`{$col}` != ?"; $bindings[] = $val; break;
                case 'gt':    $where[] = "`{$col}` > ?"; $bindings[] = $val; break;
                case 'gte':   $where[] = "`{$col}` >= ?"; $bindings[] = $val; break;
                case 'lt':    $where[] = "`{$col}` < ?"; $bindings[] = $val; break;
                case 'lte':   $where[] = "`{$col}` <= ?"; $bindings[] = $val; break;
                case 'like':  $where[] = "`{$col}` LIKE ?"; $bindings[] = $val; break;
                case 'ilike': $where[] = "`{$col}` LIKE ?"; $bindings[] = $val; break;
                case 'is':
                    if ($val === 'null') $where[] = "`{$col}` IS NULL";
                    else $where[] = "`{$col}` IS NOT NULL";
                    break;
                case 'in':
                    $inVals = is_array($val) ? $val : explode(',', $val);
                    $placeholders = implode(',', array_fill(0, count($inVals), '?'));
                    $where[] = "`{$col}` IN ({$placeholders})";
                    $bindings = array_merge($bindings, $inVals);
                    break;
                case 'contains':
                    $where[] = "JSON_CONTAINS(`{$col}`, ?)";
                    $bindings[] = is_string($val) ? $val : json_encode($val);
                    break;
                default:
                    $where[] = "`{$col}` = ?"; $bindings[] = $val;
            }
        }

        $sql = "SELECT {$select} FROM `{$table}`";
        if ($where) $sql .= " WHERE " . implode(' AND ', $where);

        // ORDER BY — validate column name
        if (!empty($params['order'])) {
            $orderParts = explode('.', $params['order']);
            $orderCol = $this->sanitizeIdentifier($orderParts[0]);
            $this->assertValidIdentifier($orderCol, 'order column');
            $orderDir = ($orderParts[1] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';
            $sql .= " ORDER BY `{$orderCol}` {$orderDir}";
        }

        // LIMIT / OFFSET — cast to int (prevents injection)
        if (isset($params['limit'])) {
            $sql .= " LIMIT " . (int) $params['limit'];
        }
        if (isset($params['offset'])) {
            $sql .= " OFFSET " . (int) $params['offset'];
        }

        $rows = $db->fetchAll($sql, $bindings);
        Response::json($rows);
    }

    /**
     * INSERT into table — POST /api/{table}
     */
    public function insert(Request $request): void
    {
        $table = $this->extractTableFromPath($request);
        $this->assertAllowed($table, 'write');
        $this->assertNotReadOnly($table);
        $this->assertAdminForTable($table, $request);

        $body = $request->json();
        if (!$body) throw new ApiException(422, 'Request body is required');

        // Support single row or array of rows
        $rows = array_is_list($body) ? $body : [$body];
        $db = Database::instance();
        $inserted = [];

        foreach ($rows as $row) {
            if (!is_array($row)) throw new ApiException(422, 'Each row must be an object');

            // Remove protected columns (mass assignment prevention)
            $row = $this->filterProtectedColumns($row);

            $cols = array_keys($row);
            // Validate all column names
            foreach ($cols as $col) {
                $this->assertValidIdentifier($this->sanitizeIdentifier($col), 'column');
            }
            $colNames = implode(', ', array_map(fn($c) => "`{$c}`", $cols));
            $placeholders = implode(', ', array_fill(0, count($cols), '?'));
            $sql = "INSERT INTO `{$table}` ({$colNames}) VALUES ({$placeholders})";
            $db->execute($sql, array_values($row));
            $inserted[] = $row;
        }

        Response::json(array_is_list($body) ? $inserted : $inserted[0], 201);
    }

    /**
     * UPDATE table — PATCH /api/{table}?col=val
     */
    public function update(Request $request): void
    {
        $table = $this->extractTableFromPath($request);
        $this->assertAllowed($table, 'write');
        $this->assertNotReadOnly($table);
        $this->assertAdminForTable($table, $request);

        $body = $request->json();
        if (!$body || !is_array($body)) throw new ApiException(422, 'Request body with update fields required');

        // Remove protected columns (mass assignment prevention)
        $body = $this->filterProtectedColumns($body);

        $params = $request->query();
        $where = [];
        $bindings = [];

        foreach ($params as $key => $value) {
            if (preg_match('/^(.+?)\.eq\.(.+)$/', $value, $m)) {
                $col = $this->sanitizeIdentifier($m[1]);
                $this->assertValidIdentifier($col, 'column');
                $where[] = "`{$col}` = ?";
                $bindings[] = $m[2];
            } else {
                $col = $this->sanitizeIdentifier($key);
                $this->assertValidIdentifier($col, 'column');
                $where[] = "`{$col}` = ?";
                $bindings[] = $value;
            }
        }

        if (!$where) throw new ApiException(422, 'WHERE conditions required (use query params)');

        $setClauses = [];
        foreach ($body as $col => $val) {
            $col = $this->sanitizeIdentifier($col);
            $this->assertValidIdentifier($col, 'column');
            $setClauses[] = "`{$col}` = ?";
            $bindings[] = $val;
        }

        $sql = "UPDATE `{$table}` SET " . implode(', ', $setClauses) . " WHERE " . implode(' AND ', $where);
        $db = Database::instance();
        $db->execute($sql, $bindings);
        Response::json(['success' => true]);
    }

    /**
     * DELETE from table — DELETE /api/{table}?col=val
     */
    public function delete(Request $request): void
    {
        $table = $this->extractTableFromPath($request);
        $this->assertAllowed($table, 'write');
        $this->assertNotReadOnly($table);
        $this->assertAdminForTable($table, $request);

        $params = $request->query();
        $where = [];
        $bindings = [];

        foreach ($params as $key => $value) {
            if (preg_match('/^(.+?)\.eq\.(.+)$/', $value, $m)) {
                $col = $this->sanitizeIdentifier($m[1]);
                $this->assertValidIdentifier($col, 'column');
                $where[] = "`{$col}` = ?";
                $bindings[] = $m[2];
            } else {
                $col = $this->sanitizeIdentifier($key);
                $this->assertValidIdentifier($col, 'column');
                $where[] = "`{$col}` = ?";
                $bindings[] = $value;
            }
        }

        if (!$where) throw new ApiException(422, 'WHERE conditions required');

        $sql = "DELETE FROM `{$table}` WHERE " . implode(' AND ', $where);
        $db = Database::instance();
        $db->execute($sql, $bindings);
        Response::json(['success' => true]);
    }

    // ── Security helpers ──────────────────────────────────────────────────────

    private function extractTableFromPath(Request $request): string
    {
        $path = $request->path();
        if (preg_match('#/(?:api/)?([a-z_]+)#', $path, $m)) {
            return $m[1];
        }
        throw new ApiException(422, 'Could not determine table name from path');
    }

    private function assertAllowed(string $table, string $operation): void
    {
        if (!in_array($table, self::ALL_TABLES, true)) {
            throw new ApiException(403, "Table '{$table}' is not accessible via data API");
        }
    }

    private function assertAdminForTable(string $table, Request $request): void
    {
        if (in_array($table, self::ADMIN_TABLES, true)) {
            $role = $request->user['role'] ?? '';
            if (!in_array($role, ['admin', 'super_admin'], true)) {
                throw new ApiException(403, "Table '{$table}' requires admin access");
            }
        }
    }

    private function assertNotReadOnly(string $table): void
    {
        if (in_array($table, self::READ_ONLY_TABLES, true)) {
            throw new ApiException(403, "Table '{$table}' is read-only via data API");
        }
    }

    private function assertValidIdentifier(string $identifier, string $context): void
    {
        if (!preg_match(self::IDENTIFIER_REGEX, $identifier)) {
            throw new ApiException(422, "Invalid {$context}: '{$identifier}'");
        }
    }

    /** Strip backticks and validate a MySQL identifier */
    private function sanitizeIdentifier(string $input): string
    {
        $clean = str_replace(['`', '"', "'", ' '], '', $input);
        return $clean;
    }

    /** Validate that select columns only contain valid identifiers */
    private function validateSelectColumns(string $select): array
    {
        if (trim($select) === '*') return ['*'];

        $parts = array_map('trim', explode(',', $select));
        foreach ($parts as $part) {
            // Allow * and table.* patterns
            if ($part === '*' || preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*\.\*$/', $part)) continue;
            $this->assertValidIdentifier($this->sanitizeIdentifier($part), 'select column');
        }
        return $parts;
    }

    /** Remove protected columns from a row (mass assignment prevention) */
    private function filterProtectedColumns(array $row): array
    {
        return array_diff_key($row, array_flip(self::PROTECTED_COLUMNS));
    }
}
