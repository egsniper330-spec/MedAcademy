<?php

declare(strict_types=1);

namespace MedAcademy\Video;

use MedAcademy\Database\Database;
use MedAcademy\Http\ApiException;
use MedAcademy\Utils\Config;

/**
 * VdoCipher server-side integration. The API secret lives only in the PHP
 * environment — it is never exposed to the mobile app.
 *
 * Port of supabase/functions/vdocipher-otp (dynamic rtext watermark for
 * students only; privileged roles get no server-side annotation), plus
 * upload-init / upload-status / delete from the matching Edge Functions.
 */
final class VdoCipherService
{
    private string $apiBase;
    private string $apiSecret;

    public function __construct()
    {
        $this->apiBase = rtrim(Config::string('VDOCIPHER_API_BASE', 'https://dev.vdocipher.com/api'), '/');
        $this->apiSecret = Config::string('VDOCIPHER_API_SECRET');
    }

    private function isConfigured(): bool
    {
        return $this->apiSecret !== '' && $this->apiSecret !== 'CHANGE_ME';
    }

    /**
     * Build the annotate watermark (JSON-stringified string — required by the
     * VdoCipher API; numeric fields as strings; color 0xRRGGBB).
     */
    public function buildAnnotate(string $fullName, string $watermarkId): string
    {
        $idLine = trim($watermarkId) !== '' ? 'ID: ' . trim($watermarkId) : '';
        $lines = array_filter([trim($fullName), $idLine]);
        $text = implode("\n", $lines);
        $annotations = [[
            'type' => 'rtext',
            'text' => $text,
            'color' => '0xFFFFFF',
            'alpha' => '0.45',
            'size' => '18',
            'interval' => '25000',
            'skip' => '2000',
        ]];
        return json_encode($annotations, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Generate a playback OTP for a lesson video.
     *
     * Access rules (ported from vdocipher-otp):
     *   - lesson must exist with matching video_id
     *   - students: lesson.status = 'published' AND enrolled in the course
     *   - doctor/admin/super_admin: may preview drafts, no enrollment needed
     */
    public function otp(string $userId, string $videoId, ?string $lessonId, ?string $ipAddress = null): array
    {
        if (!$this->isConfigured()) {
            throw new ApiException(500, 'Video service not configured');
        }

        $db = Database::instance();
        $profile = $db->row(
            'SELECT role, full_name, watermark_id FROM profiles WHERE id = ?',
            [$userId]
        );
        if ($profile === null) {
            throw new ApiException(401, 'Account not found');
        }
        $role = $profile['role'];
        $isPrivileged = in_array($role, ['doctor', 'admin', 'super_admin'], true);

        $lesson = null;
        if ($lessonId !== null && $lessonId !== '') {
            $lesson = $db->row(
                'SELECT course_id, video_id, status FROM lessons WHERE id = ? AND video_id = ?',
                [$lessonId, $videoId]
            );
            if ($lesson === null) {
                throw new ApiException($isPrivileged ? 404 : 403, $isPrivileged ? 'Lesson not found' : 'This lesson is not available');
            }
            if (!$isPrivileged && $lesson['status'] !== 'published') {
                throw new ApiException(403, 'This lesson is not available');
            }
            if (!$isPrivileged) {
                $enrolled = $db->value(
                    'SELECT COUNT(*) FROM enrollments WHERE student_id = ? AND course_id = ?',
                    [$userId, $lesson['course_id']],
                    0
                );
                if (!$enrolled) {
                    throw new ApiException(403, 'Not enrolled in this course');
                }
            }
        }

        $payload = [];
        $appDomain = Config::string('APP_URL');
        if ($appDomain !== '') {
            $payload['whitelisthref'] = $appDomain;
        }

        // Dynamic watermark for students only
        if (!$isPrivileged && $profile) {
            $name = trim((string) $profile['full_name']);
            $wmId = trim((string) $profile['watermark_id']);
            if ($name !== '' && $wmId !== '') {
                $payload['annotate'] = $this->buildAnnotate($name, $wmId);
            }
        }

        $res = $this->request('POST', '/videos/' . rawurlencode($videoId) . '/otp', $payload);
        $status = (int) $res['status'];
        $body = $res['body'];

        if ($status >= 400) {
            $errDetail = '';
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                $errDetail = $decoded['message'] ?? $decoded['error'] ?? json_encode($decoded);
            }
            throw new ApiException(502, 'Failed to generate playback token (upstream ' . $status . ')' . ($errDetail ? ': ' . $errDetail : ''));
        }
        $data = json_decode($body, true);
        if (!is_array($data)) {
            throw new ApiException(502, 'Invalid response from video service');
        }

        \MedAcademy\Services\AuditService::write($userId, 'security_event', [
            'event' => 'video_play',
            'video_id' => $videoId,
            'lesson_id' => $lessonId,
        ], $ipAddress);

        return ['otp' => $data['otp'] ?? null, 'playbackInfo' => $data['playbackInfo'] ?? null];
    }

    public function uploadInit(string $userId, array $data): array
    {
        if (!$this->isConfigured()) {
            throw new ApiException(500, 'Video service not configured');
        }
        $folderId = !empty($data['folderId'])
            ? (string) $data['folderId']
            : Config::string('VDOCIPHER_FOLDER_ID', '');
        if ($folderId === '') {
            throw new ApiException(422, 'VDOCIPHER_FOLDER_ID is not configured and no folderId was provided');
        }
        $payload = [
            'title' => (string) ($data['title'] ?? 'Untitled'),
            'folderId' => $folderId,
        ];
        $res = $this->request('POST', '/videos', $payload);
        $status = (int) $res['status'];
        $body = $res['body'];
        if ($status >= 400) {
            // Surface the actual VdoCipher error for diagnosis
            $errDetail = '';
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                $errDetail = $decoded['message'] ?? $decoded['error'] ?? json_encode($decoded);
            }
            throw new ApiException(502, 'Failed to initialise upload' . ($errDetail ? ': ' . $errDetail : ''));
        }
        $data = json_decode($body, true);
        if (!is_array($data)) {
            throw new ApiException(502, 'Invalid response from video service');
        }
        \MedAcademy\Services\AuditService::write($userId, 'video_uploaded', ['video_id' => $data['id'] ?? null]);
        return $data;
    }

    public function uploadStatus(string $uploadId): array
    {
        if (!$this->isConfigured()) {
            throw new ApiException(500, 'Video service not configured');
        }
        $res = $this->request('GET', '/uploads/' . rawurlencode($uploadId));
        if ((int) $res['status'] >= 400) {
            $errDetail = '';
            $decoded = json_decode($res['body'], true);
            if (is_array($decoded)) {
                $errDetail = $decoded['message'] ?? $decoded['error'] ?? json_encode($decoded);
            }
            throw new ApiException(502, 'Failed to fetch upload status (upstream ' . $res['status'] . ')' . ($errDetail ? ': ' . $errDetail : ''));
        }
        $data = json_decode($res['body'], true);
        return is_array($data) ? $data : [];
    }

    public function deleteVideo(string $videoId): array
    {
        if (!$this->isConfigured()) {
            throw new ApiException(500, 'Video service not configured');
        }
        $res = $this->request('DELETE', '/videos/' . rawurlencode($videoId));
        return ['status' => (int) $res['status']];
    }

    private function request(string $method, string $path, array $body = []): array
    {
        $ch = curl_init($this->apiBase . $path);
        $headers = [
            'Authorization: Apisecret ' . $this->apiSecret,
            'Content-Type: application/json',
        ];
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        if ($body !== []) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }
        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return ['status' => $status, 'body' => is_string($raw) ? $raw : ''];
    }
}
